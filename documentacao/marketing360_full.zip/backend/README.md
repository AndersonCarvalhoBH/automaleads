# Backend - Marketing360

## Local dev
- copy .env.example to .env and adjust
- npm install
- npx prisma generate
- npx prisma migrate dev --name init
- npm run dev
