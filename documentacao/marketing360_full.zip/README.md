# Marketing360 - Scaffold

This repository contains a scaffold for the Marketing360 SaaS system (backend + frontend + infra).
- Start with `infra/docker-compose.yml` for local dev.
- Backend runs on port 4000, frontend on 5173 (proxied to 3000 in compose).
