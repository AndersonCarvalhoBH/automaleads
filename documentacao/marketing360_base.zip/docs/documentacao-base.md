# Documentação Base - Sistema Marketing 360 White Label
## Visão Geral
Sistema SaaS completo para captação, qualificação, automação e gestão omnichannel de leads.
(... resumido por espaço ...)
